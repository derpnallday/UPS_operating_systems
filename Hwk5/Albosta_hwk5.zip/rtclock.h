/*
 * rtclock.h
 *
 *  Created on: Jan 21, 2016
 *      Author: dchiu
 */

#ifndef RTCLOCK_H_
#define RTCLOCK_H_

#include <sys/time.h>
#include <stdio.h>

double rtclock();

#endif /* RTCLOCK_H_ */
