/*
 * bartender.h
 *
 *  Created on: Dec 26, 2015
 *      Author: dchiu
 */

#ifndef BARTENDER_H_
#define BARTENDER_H_

void* bartender(void* args);
void makeDrink();
void waitForCustomer();
void receivePayment();


#endif /* BARTENDER_H_ */
