#include "stats.h"
#include <stdio.h>
#include <string.h>

#define MAX_INPUT_LEN 128
#define Alphabet_Len 26



int processMenu(WordStats w);